************************************************************
* Replication code: CDC NREVSS RSV example
* Weekly RSV NAAT positivity, 10 HHS regions, 2022-2026
************************************************************

use "nrevss_rsv_hhs_regions_2022_2026.dta", clear

* Declare panel structure
xtset region_id week_index

************************************
* 1. Examine AR order: AR(1)-AR(5)
***********************************

forvalues k = 1/5 {

    xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
        lag(`k') vce(oim)

    * Standardized one-step-ahead conditional residual; missing for the
    * first k observations of each panel (conditioning observations)
    predict rstd`k', rstandard
}


*****************************************************
* 2. Residual white-noise diagnostics by HHS region
*****************************************************

forvalues k = 1/5 {

    di _newline "================================"
    di "AR(`k')"
    di "================================"

    forvalues i = 1/10 {
        di _newline "HHS REGION `i'"
        wntestq rstd`k' if region_id == `i', lags(12)
    }
}


***************************************************************
* 3. Final beta-AR(5) model: alternative covariance estimators
***************************************************************

* Observed information matrix
xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
    lag(5) vce(oim)

* Panel-corrected standard errors
xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
    lag(5) vce(pcse)

* Driscoll-Kraay, L = 0:
* unrestricted contemporaneous score sandwich
xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
    lag(5) vce(dk) dklag(0)

* Driscoll-Kraay, Newey-West bandwidth:
* floor[4(T/100)^(2/9)] = 4 for T = 210
xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
    lag(5) vce(dk) dklag(4)

* Driscoll-Kraay, L = k = 5
xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
    lag(5) vce(dk) dklag(5)

* Driscoll-Kraay, L = 2k = 10
xtbetark rsv_adj sin52 cos52 sin26 cos26 i.region_id, ///
    lag(5) vce(dk) dklag(10)
	
* graph it
twoway ///
    (line rsv_pos date if region_id==1,  lpattern(solid)) ///
    (line rsv_pos date if region_id==2,  lpattern(dash)) ///
    (line rsv_pos date if region_id==3,  lpattern(dot)) ///
    (line rsv_pos date if region_id==4,  lpattern(shortdash)) ///
    (line rsv_pos date if region_id==5,  lpattern(longdash)) ///
    (line rsv_pos date if region_id==6,  lpattern(dash_dot)) ///
    (line rsv_pos date if region_id==7,  lpattern(solid) ///
        lwidth(medthick)) ///
    (line rsv_pos date if region_id==8,  lpattern(dash) ///
        lwidth(medthick)) ///
    (line rsv_pos date if region_id==9,  lpattern(dot) ///
        lwidth(medthick)) ///
    (line rsv_pos date if region_id==10, lpattern(shortdash) ///
        lwidth(medthick)), ///
    ytitle("RSV test positivity (%)", margin(r+4)) ///
    ylabel(0 "0%" .1 "10%" .2 "20%" .3 "30%", ///
        angle(horizontal) labsize(small)) ///
    xtitle("") ///
    xlabel(, format(%tdMon_CCYY) angle(45) labsize(small)) ///
    legend(order(1 "Region 1" 2 "Region 2" 3 "Region 3" ///
                 4 "Region 4" 5 "Region 5" 6 "Region 6" ///
                 7 "Region 7" 8 "Region 8" 9 "Region 9" ///
                 10 "Region 10") ///
           position(6) rows(2) size(small) ///
           region(lstyle(none))) ///
    scheme(s1mono)
	

	